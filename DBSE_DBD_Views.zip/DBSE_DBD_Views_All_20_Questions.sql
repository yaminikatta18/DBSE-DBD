-- DBSE & DBD - SQL Views Practical
-- Topic: VIEWS
CREATE DATABASE IF NOT EXISTS BankDB;
USE BankDB;

CREATE TABLE Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(15),
    Email VARCHAR(100),
    City VARCHAR(50)
);

CREATE TABLE Account (
    Account_No INT PRIMARY KEY,
    Customer_ID INT,
    Account_Type VARCHAR(20),
    Balance DECIMAL(12,2),
    Branch VARCHAR(50),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

CREATE TABLE Bank_Transaction (
    Transaction_ID INT PRIMARY KEY AUTO_INCREMENT,
    Account_No INT,
    Transaction_Type VARCHAR(20),
    Amount DECIMAL(12,2),
    Transaction_Date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Account_No) REFERENCES Account(Account_No)
);

CREATE TABLE Loan (
    Loan_ID INT PRIMARY KEY,
    Customer_ID INT,
    Loan_Type VARCHAR(30),
    Loan_Amount DECIMAL(12,2),
    Interest_Rate DECIMAL(5,2),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

INSERT INTO Customer VALUES
(101,'Ravi Kumar','9876543210','ravi@gmail.com','Hyderabad'),
(102,'Priya Sharma','9876543211','priya@gmail.com','Vijayawada'),
(103,'Arjun Reddy','9876543212','arjun@gmail.com','Bangalore'),
(104,'Sneha Rao','9876543213','sneha@gmail.com','Chennai'),
(105,'Kiran Kumar','9876543214','kiran@gmail.com','Hyderabad'),
(106,'Anil Kumar','9876543215','anil@gmail.com','Delhi'),
(107,'Meena Reddy','9876543216','meena@gmail.com','Mumbai'),
(108,'Rahul Sharma','9876543217','rahul@gmail.com','Pune'),
(109,'Lakshmi Devi','9876543218','lakshmi@gmail.com','Hyderabad'),
(110,'Suresh Babu','9876543219','suresh@gmail.com','Vijayawada');

INSERT INTO Account VALUES
(10001,101,'Savings',50000,'Hyderabad'),
(10002,102,'Savings',75000,'Vijayawada'),
(10003,103,'Current',120000,'Bangalore'),
(10004,104,'Savings',45000,'Chennai'),
(10005,105,'Current',90000,'Hyderabad'),
(10006,106,'Savings',65000,'Delhi'),
(10007,107,'Current',150000,'Mumbai'),
(10008,108,'Savings',35000,'Pune'),
(10009,109,'Savings',85000,'Hyderabad'),
(10010,110,'Current',110000,'Vijayawada');

INSERT INTO Bank_Transaction (Account_No, Transaction_Type, Amount) VALUES
(10001,'DEPOSIT',10000),(10001,'WITHDRAW',5000),
(10002,'DEPOSIT',15000),(10003,'WITHDRAW',20000),
(10004,'DEPOSIT',5000),(10005,'WITHDRAW',10000),
(10006,'DEPOSIT',12000),(10007,'DEPOSIT',25000),
(10008,'WITHDRAW',5000),(10009,'DEPOSIT',20000),
(10010,'WITHDRAW',15000);

INSERT INTO Loan VALUES
(501,101,'Home Loan',5000000,7.5),
(502,102,'Education Loan',1000000,6.5),
(503,103,'Car Loan',800000,8.2),
(504,104,'Personal Loan',500000,10.5),
(505,105,'Home Loan',4000000,7.2),
(506,106,'Car Loan',900000,8.5),
(507,107,'Business Loan',3000000,9.0),
(508,109,'Personal Loan',600000,10.0);


-- QUESTION 1
CREATE OR REPLACE VIEW Q1_Customer_Account_View AS
SELECT C.Customer_ID, C.Customer_Name, A.Account_No, A.Account_Type, A.Balance
FROM Customer C JOIN Account A ON C.Customer_ID = A.Customer_ID;
SELECT * FROM Q1_Customer_Account_View;

-- QUESTION 2
CREATE OR REPLACE VIEW Q2_Savings_Above_50000 AS
SELECT * FROM Account
WHERE Account_Type = 'Savings' AND Balance > 50000;
SELECT * FROM Q2_Savings_Above_50000;

-- QUESTION 3
CREATE OR REPLACE VIEW Q3_Hyderabad_Current_Accounts AS
SELECT * FROM Account
WHERE Account_Type = 'Current' AND Branch = 'Hyderabad';
SELECT * FROM Q3_Hyderabad_Current_Accounts;

-- QUESTION 4
CREATE OR REPLACE VIEW Q4_Top_Balance_Accounts AS
SELECT Account_No, Customer_ID, Account_Type, Balance
FROM Account
ORDER BY Balance DESC;
SELECT * FROM Q4_Top_Balance_Accounts;

-- QUESTION 5
CREATE OR REPLACE VIEW Q5_Customers_With_Loans AS
SELECT C.Customer_Name, C.City, L.Loan_Type, L.Loan_Amount
FROM Customer C JOIN Loan L ON C.Customer_ID = L.Customer_ID;
SELECT * FROM Q5_Customers_With_Loans;

-- QUESTION 6
CREATE OR REPLACE VIEW Q6_Loans_Above_1000000 AS
SELECT C.Customer_Name, C.City, L.Loan_Type, L.Loan_Amount
FROM Customer C JOIN Loan L ON C.Customer_ID = L.Customer_ID
WHERE L.Loan_Amount > 1000000;
SELECT * FROM Q6_Loans_Above_1000000;

-- QUESTION 7
CREATE OR REPLACE VIEW Q7_Branch_Total_Balance AS
SELECT Branch, SUM(Balance) AS Total_Balance
FROM Account
GROUP BY Branch;
SELECT * FROM Q7_Branch_Total_Balance;

-- QUESTION 8
CREATE OR REPLACE VIEW Q8_Account_Type_Average_Balance AS
SELECT Account_Type, AVG(Balance) AS Average_Balance
FROM Account
GROUP BY Account_Type;
SELECT * FROM Q8_Account_Type_Average_Balance;

-- QUESTION 9
CREATE OR REPLACE VIEW Q9_City_Customer_Count AS
SELECT City, COUNT(*) AS Number_of_Customers
FROM Customer
GROUP BY City;
SELECT * FROM Q9_City_Customer_Count;

-- QUESTION 10
CREATE OR REPLACE VIEW Q10_Rich_Branches AS
SELECT Branch, SUM(Balance) AS Total_Balance
FROM Account
GROUP BY Branch
HAVING SUM(Balance) > 200000;
SELECT * FROM Q10_Rich_Branches;

-- QUESTION 11
CREATE OR REPLACE VIEW Q11_Deposit_Transactions AS
SELECT Transaction_ID, Account_No, Amount, Transaction_Date
FROM Bank_Transaction
WHERE Transaction_Type = 'DEPOSIT';
SELECT * FROM Q11_Deposit_Transactions;

-- QUESTION 12
CREATE OR REPLACE VIEW Q12_High_Withdrawals AS
SELECT Transaction_ID, Account_No, Amount, Transaction_Date
FROM Bank_Transaction
WHERE Transaction_Type = 'WITHDRAW' AND Amount > 10000;
SELECT * FROM Q12_High_Withdrawals;

-- QUESTION 13
CREATE OR REPLACE VIEW Q13_Customer_Transactions AS
SELECT C.Customer_Name, A.Account_No, A.Account_Type,
       T.Transaction_Type, T.Amount, T.Transaction_Date
FROM Customer C
JOIN Account A ON C.Customer_ID = A.Customer_ID
JOIN Bank_Transaction T ON A.Account_No = T.Account_No;
SELECT * FROM Q13_Customer_Transactions;

-- QUESTION 14
CREATE OR REPLACE VIEW Q14_Customer_Account_Loan AS
SELECT C.Customer_Name, A.Account_No, A.Account_Type,
       A.Balance, L.Loan_Type, L.Loan_Amount
FROM Customer C
JOIN Account A ON C.Customer_ID = A.Customer_ID
LEFT JOIN Loan L ON C.Customer_ID = L.Customer_ID;
SELECT * FROM Q14_Customer_Account_Loan;

-- QUESTION 15
CREATE OR REPLACE VIEW Q15_Annual_Loan_Interest AS
SELECT Loan_ID, Customer_ID, Loan_Type, Loan_Amount,
       Interest_Rate,
       (Loan_Amount * Interest_Rate / 100) AS Annual_Interest
FROM Loan;
SELECT * FROM Q15_Annual_Loan_Interest;

-- QUESTION 16
CREATE OR REPLACE VIEW Q16_Loan_Total_Amount AS
SELECT Loan_ID, Customer_ID, Loan_Type, Loan_Amount,
       Interest_Rate,
       (Loan_Amount * Interest_Rate / 100) AS Annual_Interest,
       Loan_Amount + (Loan_Amount * Interest_Rate / 100) AS Total_Amount
FROM Loan;
SELECT * FROM Q16_Loan_Total_Amount;

-- QUESTION 17
CREATE OR REPLACE VIEW Q17_Branches_More_Than_Two_Accounts AS
SELECT Branch, COUNT(*) AS Number_of_Accounts
FROM Account
GROUP BY Branch
HAVING COUNT(*) > 2;
SELECT * FROM Q17_Branches_More_Than_Two_Accounts;

-- QUESTION 18
CREATE OR REPLACE VIEW Q18_Account_Types_Total_Balance AS
SELECT Account_Type, SUM(Balance) AS Total_Balance
FROM Account
GROUP BY Account_Type
HAVING SUM(Balance) > 200000;
SELECT * FROM Q18_Account_Types_Total_Balance;

-- QUESTION 19
CREATE OR REPLACE VIEW Q19_Balance_Between_50000_100000 AS
SELECT C.Customer_ID, C.Customer_Name, A.Account_No,
       A.Account_Type, A.Balance
FROM Customer C
JOIN Account A ON C.Customer_ID = A.Customer_ID
WHERE A.Balance BETWEEN 50000 AND 100000;
SELECT * FROM Q19_Balance_Between_50000_100000;

-- QUESTION 20
CREATE OR REPLACE VIEW Q20_Highest_Balance_Per_Branch AS
SELECT A.Branch, A.Account_No, A.Customer_ID,
       A.Account_Type, A.Balance
FROM Account A
WHERE A.Balance = (
    SELECT MAX(A2.Balance)
    FROM Account A2
    WHERE A2.Branch = A.Branch
);
SELECT * FROM Q20_Highest_Balance_Per_Branch;