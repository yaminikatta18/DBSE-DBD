-- Week 2 Practical: BookFlow Library Database
CREATE DATABASE IF NOT EXISTS bookflow_db;
USE bookflow_db;
