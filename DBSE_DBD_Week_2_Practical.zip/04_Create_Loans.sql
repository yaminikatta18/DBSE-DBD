USE bookflow_db;

CREATE TABLE Loans (
    loan_id INT PRIMARY KEY,
    member_id INT,
    book_id INT,
    loan_date DATE,
    FOREIGN KEY (member_id) REFERENCES Members(member_id),
    FOREIGN KEY (book_id) REFERENCES Books(book_id)
);

INSERT INTO Loans (loan_id, member_id, book_id, loan_date) VALUES
(1, 101, 1, '2025-01-05'),
(2, 102, 2, '2025-01-08'),
(3, 103, 3, '2025-01-10'),
(4, 101, 2, '2025-02-01'),
(5, 102, 1, '2025-02-05'),
(6, 103, 2, '2025-02-12'),
(7, 101, 3, '2025-03-01'),
(8, 102, 3, '2025-03-07'),
(9, 103, 1, '2025-03-15'),
(10, 101, 1, '2025-04-01');

SELECT * FROM Loans;
