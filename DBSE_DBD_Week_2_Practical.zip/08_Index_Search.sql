USE bookflow_db;

CREATE INDEX idx_books_isbn ON Books(isbn);

SELECT * FROM Books
WHERE isbn = '9780451524935';
