USE bookflow_db;

-- Show which member borrowed which book
SELECT m.full_name AS Member_Name,
       b.title AS Book_Title
FROM Loans l
INNER JOIN Members m ON l.member_id = m.member_id
INNER JOIN Books b ON l.book_id = b.book_id;
