-- DBSE & DBD - Week 4 Practical
-- Topic: ACID Properties & Transaction Isolation
-- Bank Database

CREATE DATABASE IF NOT EXISTS Bank_ACID_DB;
USE Bank_ACID_DB;

CREATE TABLE IF NOT EXISTS Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(15),
    City VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Account (
    Account_No INT PRIMARY KEY,
    Customer_ID INT,
    Account_Type VARCHAR(20),
    Balance DECIMAL(12,2),
    Branch VARCHAR(50),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

CREATE TABLE IF NOT EXISTS Bank_Transaction (
    Transaction_ID INT PRIMARY KEY AUTO_INCREMENT,
    Account_No INT,
    Transaction_Type VARCHAR(20),
    Amount DECIMAL(12,2),
    Transaction_Date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Account_No) REFERENCES Account(Account_No)
);

INSERT IGNORE INTO Customer VALUES
(101,'Ravi Kumar','9876543210','Hyderabad'),
(102,'Priya Sharma','9876543211','Vijayawada'),
(103,'Arjun Reddy','9876543212','Bangalore'),
(104,'Sneha Rao','9876543213','Chennai'),
(105,'Kiran Kumar','9876543214','Hyderabad');

INSERT IGNORE INTO Account VALUES
(10001,101,'Savings',50000,'Hyderabad'),
(10002,102,'Savings',75000,'Vijayawada'),
(10003,103,'Current',120000,'Bangalore'),
(10004,104,'Savings',45000,'Chennai'),
(10005,105,'Current',90000,'Hyderabad');

INSERT INTO Bank_Transaction (Account_No, Transaction_Type, Amount) VALUES
(10001,'DEPOSIT',10000),
(10002,'DEPOSIT',15000),
(10003,'WITHDRAW',20000),
(10004,'DEPOSIT',5000),
(10005,'WITHDRAW',10000);


-- QUESTION 15
-- General comparison:
-- READ UNCOMMITTED: Dirty Read = possible; Non-Repeatable Read = possible; Phantom Read = possible
-- READ COMMITTED: Dirty Read = prevented; Non-Repeatable Read = possible; Phantom Read = possible
-- REPEATABLE READ: Dirty Read = prevented; Non-Repeatable Read = prevented for consistent reads; Phantom behavior depends on implementation
-- SERIALIZABLE: Dirty Read = prevented; Non-Repeatable Read = prevented; Phantom Read = prevented through serial execution/locking

SELECT @@SESSION.transaction_isolation;
