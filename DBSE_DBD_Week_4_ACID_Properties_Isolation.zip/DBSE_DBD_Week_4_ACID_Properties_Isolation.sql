-- DBSE & DBD - Week 4 Practical
-- Topic: ACID Properties & Transaction Isolation
-- Bank Database

CREATE DATABASE IF NOT EXISTS Bank_ACID_DB;
USE Bank_ACID_DB;

CREATE TABLE IF NOT EXISTS Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(15),
    City VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Account (
    Account_No INT PRIMARY KEY,
    Customer_ID INT,
    Account_Type VARCHAR(20),
    Balance DECIMAL(12,2),
    Branch VARCHAR(50),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

CREATE TABLE IF NOT EXISTS Bank_Transaction (
    Transaction_ID INT PRIMARY KEY AUTO_INCREMENT,
    Account_No INT,
    Transaction_Type VARCHAR(20),
    Amount DECIMAL(12,2),
    Transaction_Date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Account_No) REFERENCES Account(Account_No)
);

INSERT IGNORE INTO Customer VALUES
(101,'Ravi Kumar','9876543210','Hyderabad'),
(102,'Priya Sharma','9876543211','Vijayawada'),
(103,'Arjun Reddy','9876543212','Bangalore'),
(104,'Sneha Rao','9876543213','Chennai'),
(105,'Kiran Kumar','9876543214','Hyderabad');

INSERT IGNORE INTO Account VALUES
(10001,101,'Savings',50000,'Hyderabad'),
(10002,102,'Savings',75000,'Vijayawada'),
(10003,103,'Current',120000,'Bangalore'),
(10004,104,'Savings',45000,'Chennai'),
(10005,105,'Current',90000,'Hyderabad');

INSERT INTO Bank_Transaction (Account_No, Transaction_Type, Amount) VALUES
(10001,'DEPOSIT',10000),
(10002,'DEPOSIT',15000),
(10003,'WITHDRAW',20000),
(10004,'DEPOSIT',5000),
(10005,'WITHDRAW',10000);


-- QUESTION 1
START TRANSACTION;
UPDATE Account
SET Balance = Balance + 5000
WHERE Account_No = 10001;
COMMIT;

-- QUESTION 2
START TRANSACTION;
UPDATE Account
SET Balance = Balance - 3000
WHERE Account_No = 10002;
COMMIT;

-- QUESTION 3
START TRANSACTION;
UPDATE Account
SET Balance = Balance - 10000
WHERE Account_No = 10001;
ROLLBACK;

-- QUESTION 4
START TRANSACTION;

UPDATE Account
SET Balance = Balance - 15000
WHERE Account_No = 10001;

UPDATE Account
SET Balance = Balance + 15000
WHERE Account_No = 10002;

COMMIT;

-- QUESTION 5
START TRANSACTION;

UPDATE Account
SET Balance = Balance - 20000
WHERE Account_No = 10001;

SAVEPOINT AfterDebit;

UPDATE Account
SET Balance = Balance + 20000
WHERE Account_No = 10003;

COMMIT;

-- QUESTION 6
START TRANSACTION;

UPDATE Account SET Balance = Balance + 1000 WHERE Account_No = 10001;
SAVEPOINT FirstUpdate;

UPDATE Account SET Balance = Balance - 2000 WHERE Account_No = 10002;
SAVEPOINT SecondUpdate;

UPDATE Account SET Balance = Balance + 3000 WHERE Account_No = 10003;

ROLLBACK TO SAVEPOINT SecondUpdate;

COMMIT;

-- QUESTION 7
START TRANSACTION;

UPDATE Account
SET Balance = Balance - 10000
WHERE Account_No = 10001;

UPDATE Account
SET Balance = Balance + 10000
WHERE Account_No = 10002;

COMMIT;

-- If any operation fails before COMMIT, use:
-- ROLLBACK;

-- QUESTION 8
SELECT SUM(Balance) AS Total_Before
FROM Account;

START TRANSACTION;

UPDATE Account SET Balance = Balance - 10000 WHERE Account_No = 10001;
UPDATE Account SET Balance = Balance + 10000 WHERE Account_No = 10002;

COMMIT;

SELECT SUM(Balance) AS Total_After
FROM Account;

-- Total_Before and Total_After should be equal.

-- QUESTION 9
START TRANSACTION;

UPDATE Account
SET Balance = Balance + 5000
WHERE Account_No = 10001;

COMMIT;

-- Reconnect to MySQL and run:
SELECT Account_No, Balance
FROM Account
WHERE Account_No = 10001;

-- The committed balance remains stored.

-- QUESTION 10
-- SESSION 1
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
START TRANSACTION;

UPDATE Account
SET Balance = Balance + 20000
WHERE Account_No = 10001;

-- Do not COMMIT yet.

-- SESSION 2
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
START TRANSACTION;

SELECT Balance
FROM Account
WHERE Account_No = 10001;

-- Session 2 may see the uncommitted value.

-- SESSION 1
ROLLBACK;

-- SESSION 2
SELECT Balance
FROM Account
WHERE Account_No = 10001;
COMMIT;

-- QUESTION 11
-- SESSION 1
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;

UPDATE Account
SET Balance = Balance + 10000
WHERE Account_No = 10001;

-- Do not COMMIT yet.

-- SESSION 2
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;

SELECT Balance
FROM Account
WHERE Account_No = 10001;

-- The uncommitted update is not visible.

-- SESSION 1
COMMIT;

-- SESSION 2
SELECT Balance
FROM Account
WHERE Account_No = 10001;
COMMIT;

-- QUESTION 12
-- SESSION 1
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
START TRANSACTION;

SELECT Balance
FROM Account
WHERE Account_No = 10001;

-- SESSION 2
START TRANSACTION;

UPDATE Account
SET Balance = Balance + 5000
WHERE Account_No = 10001;
COMMIT;

-- SESSION 1
SELECT Balance
FROM Account
WHERE Account_No = 10001;
COMMIT;

-- Under MySQL InnoDB REPEATABLE READ, consistent reads normally use the same snapshot.

-- QUESTION 13
-- SESSION 1
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;
START TRANSACTION;

SELECT *
FROM Account
WHERE Account_No = 10001;

-- SESSION 2
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;
START TRANSACTION;

UPDATE Account
SET Balance = Balance + 5000
WHERE Account_No = 10001;

-- The second transaction may wait for the required lock.

-- SESSION 1
COMMIT;

-- SESSION 2
COMMIT;

-- QUESTION 14
SELECT 'READ UNCOMMITTED' AS Isolation_Level,
       'Lowest isolation; may allow dirty reads' AS Description
UNION ALL
SELECT 'READ COMMITTED',
       'Reads only committed data'
UNION ALL
SELECT 'REPEATABLE READ',
       'Consistent repeated reads; MySQL InnoDB default'
UNION ALL
SELECT 'SERIALIZABLE',
       'Strongest standard isolation; lowest concurrency';

-- QUESTION 15
-- General comparison:
-- READ UNCOMMITTED: Dirty Read = possible; Non-Repeatable Read = possible; Phantom Read = possible
-- READ COMMITTED: Dirty Read = prevented; Non-Repeatable Read = possible; Phantom Read = possible
-- REPEATABLE READ: Dirty Read = prevented; Non-Repeatable Read = prevented for consistent reads; Phantom behavior depends on implementation
-- SERIALIZABLE: Dirty Read = prevented; Non-Repeatable Read = prevented; Phantom Read = prevented through serial execution/locking

SELECT @@SESSION.transaction_isolation;

-- QUESTION 16
START TRANSACTION;

-- Sender debit
UPDATE Account
SET Balance = Balance - 15000
WHERE Account_No = 10001;

-- Receiver account 99999 does not exist
UPDATE Account
SET Balance = Balance + 15000
WHERE Account_No = 99999;

-- Verify the receiver before committing
IF 0 THEN
    COMMIT;
ELSE
    ROLLBACK;
END IF;

-- In MySQL, IF cannot be used directly outside a stored program.
-- For a practical manual test, check:
SELECT * FROM Account WHERE Account_No = 99999;
ROLLBACK;

-- QUESTION 17
START TRANSACTION;

SELECT Balance
FROM Account
WHERE Account_No = 10001;

-- Check that the sender has enough balance before committing.
-- Example withdrawal:
UPDATE Account
SET Balance = Balance - 1000000
WHERE Account_No = 10001
  AND Balance >= 1000000;

-- If ROW_COUNT() = 0, the transaction should not be committed.
ROLLBACK;

-- QUESTION 18
START TRANSACTION;

UPDATE Account
SET Balance = Balance + 5000
WHERE Account_No = 10001;

SAVEPOINT AfterDeposit;

UPDATE Account
SET Balance = Balance - 2000
WHERE Account_No = 10002;

ROLLBACK TO SAVEPOINT AfterDeposit;

COMMIT;

SELECT Account_No, Balance
FROM Account
WHERE Account_No IN (10001, 10002);

-- QUESTION 19
SELECT @@SESSION.transaction_isolation;

SELECT @@GLOBAL.transaction_isolation;

-- QUESTION 20
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;

SELECT @@SESSION.transaction_isolation;