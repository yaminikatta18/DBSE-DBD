-- DBSE & DBD - Week 3 Practical
-- Bank Database - Triggers and Stored Procedures
-- Based on the uploaded practical material

CREATE DATABASE IF NOT EXISTS BankDB;
USE BankDB;

CREATE TABLE IF NOT EXISTS Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(15),
    Email VARCHAR(100),
    City VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Account (
    Account_No INT PRIMARY KEY,
    Customer_ID INT,
    Account_Type VARCHAR(20),
    Balance DECIMAL(12,2) DEFAULT 0,
    Branch VARCHAR(50),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

CREATE TABLE IF NOT EXISTS Bank_Transaction (
    Transaction_ID INT PRIMARY KEY AUTO_INCREMENT,
    Account_No INT,
    Transaction_Type VARCHAR(20),
    Amount DECIMAL(12,2),
    Transaction_Date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Account_No) REFERENCES Account(Account_No)
);

CREATE TABLE IF NOT EXISTS Loan (
    Loan_ID INT PRIMARY KEY,
    Customer_ID INT,
    Loan_Type VARCHAR(30),
    Loan_Amount DECIMAL(12,2),
    Interest_Rate DECIMAL(5,2),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

INSERT IGNORE INTO Customer VALUES
(101,'Ravi Kumar','9876543210','ravi@gmail.com','Hyderabad'),
(102,'Priya Sharma','9876543211','priya@gmail.com','Vijayawada'),
(103,'Arjun Reddy','9876543212','arjun@gmail.com','Bangalore'),
(104,'Sneha Rao','9876543213','sneha@gmail.com','Chennai'),
(105,'Kiran Kumar','9876543214','kiran@gmail.com','Hyderabad');

INSERT IGNORE INTO Account VALUES
(10001,101,'Savings',50000,'Hyderabad'),
(10002,102,'Savings',75000,'Vijayawada'),
(10003,103,'Current',120000,'Bangalore'),
(10004,104,'Savings',45000,'Chennai'),
(10005,105,'Current',90000,'Hyderabad');

INSERT IGNORE INTO Loan VALUES
(501,101,'Home Loan',5000000,7.5),
(502,102,'Education Loan',1000000,6.5),
(503,103,'Car Loan',800000,8.2),
(504,104,'Personal Loan',500000,10.5);


-- QUESTION 1
DELIMITER //
CREATE PROCEDURE GetBranchAccounts(IN p_Branch VARCHAR(50))
BEGIN
    SELECT * FROM Account
    WHERE Branch = p_Branch;
END //
DELIMITER ;

CALL GetBranchAccounts('Hyderabad');

-- QUESTION 2
DELIMITER //
CREATE PROCEDURE GetCustomerAccountDetails(IN p_Customer_ID INT)
BEGIN
    SELECT C.Customer_Name, C.Phone, C.Email,
           A.Account_No, A.Account_Type, A.Balance
    FROM Customer C
    JOIN Account A ON C.Customer_ID = A.Customer_ID
    WHERE C.Customer_ID = p_Customer_ID;
END //
DELIMITER ;

CALL GetCustomerAccountDetails(101);

-- QUESTION 3
DELIMITER //
CREATE PROCEDURE GetTotalCustomerBalance(IN p_Customer_ID INT)
BEGIN
    SELECT C.Customer_ID, C.Customer_Name,
           COALESCE(SUM(A.Balance), 0) AS Total_Balance
    FROM Customer C
    LEFT JOIN Account A ON C.Customer_ID = A.Customer_ID
    WHERE C.Customer_ID = p_Customer_ID
    GROUP BY C.Customer_ID, C.Customer_Name;
END //
DELIMITER ;

CALL GetTotalCustomerBalance(101);

-- QUESTION 4
DELIMITER //
CREATE PROCEDURE HighBalanceAccounts(IN MinimumBalance DECIMAL(12,2))
BEGIN
    SELECT * FROM Account
    WHERE Balance > MinimumBalance
    ORDER BY Balance DESC;
END //
DELIMITER ;

CALL HighBalanceAccounts(100000);

-- QUESTION 5
DELIMITER //
CREATE TRIGGER CheckBalance
BEFORE UPDATE ON Account
FOR EACH ROW
BEGIN
    IF NEW.Balance < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transaction failed: Insufficient balance';
    END IF;
END //
DELIMITER ;

-- QUESTION 6
DELIMITER //
CREATE TRIGGER CheckTransactionAmount
BEFORE INSERT ON Bank_Transaction
FOR EACH ROW
BEGIN
    IF NEW.Amount <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transaction amount must be greater than zero';
    END IF;
END //
DELIMITER ;

-- QUESTION 7
CREATE TABLE IF NOT EXISTS Transaction_Audit (
    Audit_ID INT PRIMARY KEY AUTO_INCREMENT,
    Transaction_ID INT,
    Account_No INT,
    Transaction_Type VARCHAR(20),
    Amount DECIMAL(12,2),
    Audit_Date DATETIME DEFAULT CURRENT_TIMESTAMP
);

DELIMITER //
CREATE TRIGGER TransactionAudit
AFTER INSERT ON Bank_Transaction
FOR EACH ROW
BEGIN
    INSERT INTO Transaction_Audit
    (Transaction_ID, Account_No, Transaction_Type, Amount)
    VALUES
    (NEW.Transaction_ID, NEW.Account_No, NEW.Transaction_Type, NEW.Amount);
END //
DELIMITER ;

-- QUESTION 8
DELIMITER //
CREATE TRIGGER UpdateBalanceAfterDeposit
AFTER INSERT ON Bank_Transaction
FOR EACH ROW
BEGIN
    IF NEW.Transaction_Type = 'DEPOSIT' THEN
        UPDATE Account
        SET Balance = Balance + NEW.Amount
        WHERE Account_No = NEW.Account_No;
    END IF;
END //
DELIMITER ;

-- QUESTION 9
DELIMITER //
CREATE TRIGGER UpdateBalanceAfterWithdraw
AFTER INSERT ON Bank_Transaction
FOR EACH ROW
BEGIN
    IF NEW.Transaction_Type = 'WITHDRAW' THEN
        UPDATE Account
        SET Balance = Balance - NEW.Amount
        WHERE Account_No = NEW.Account_No;
    END IF;
END //
DELIMITER ;

-- QUESTION 10
DELIMITER //
CREATE TRIGGER PreventInsufficientWithdrawal
BEFORE INSERT ON Bank_Transaction
FOR EACH ROW
BEGIN
    DECLARE CurrentBalance DECIMAL(12,2);

    SELECT Balance INTO CurrentBalance
    FROM Account
    WHERE Account_No = NEW.Account_No;

    IF NEW.Transaction_Type = 'WITHDRAW'
       AND NEW.Amount > CurrentBalance THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Withdrawal failed: Insufficient balance';
    END IF;
END //
DELIMITER ;

-- QUESTION 11
DELIMITER //
CREATE PROCEDURE TransferMoney(
    IN SenderAccount INT,
    IN ReceiverAccount INT,
    IN TransferAmount DECIMAL(12,2)
)
BEGIN
    DECLARE SenderBalance DECIMAL(12,2);
    DECLARE SenderExists INT DEFAULT 0;
    DECLARE ReceiverExists INT DEFAULT 0;

    SELECT COUNT(*) INTO SenderExists
    FROM Account WHERE Account_No = SenderAccount;

    SELECT COUNT(*) INTO ReceiverExists
    FROM Account WHERE Account_No = ReceiverAccount;

    IF SenderExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transfer failed: Sender account does not exist';
    ELSEIF ReceiverExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transfer failed: Receiver account does not exist';
    ELSEIF TransferAmount <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transfer amount must be greater than zero';
    ELSE
        SELECT Balance INTO SenderBalance
        FROM Account WHERE Account_No = SenderAccount;

        IF SenderBalance < TransferAmount THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Transfer failed: Insufficient balance';
        ELSE
            START TRANSACTION;

            UPDATE Account
            SET Balance = Balance - TransferAmount
            WHERE Account_No = SenderAccount;

            UPDATE Account
            SET Balance = Balance + TransferAmount
            WHERE Account_No = ReceiverAccount;

            COMMIT;
        END IF;
    END IF;
END //
DELIMITER ;

CALL TransferMoney(10001, 10002, 5000);

-- QUESTION 12
DELIMITER //
CREATE PROCEDURE CalculateLoanInterest(
    IN LoanAmount DECIMAL(12,2),
    IN InterestRate DECIMAL(5,2),
    IN NumberOfYears INT
)
BEGIN
    SELECT
        (LoanAmount * InterestRate * NumberOfYears) / 100 AS Simple_Interest,
        LoanAmount + ((LoanAmount * InterestRate * NumberOfYears) / 100) AS Total_Amount;
END //
DELIMITER ;

CALL CalculateLoanInterest(500000, 7.5, 5);

-- QUESTION 13
DELIMITER //
CREATE TRIGGER PreventCustomerDeletionWithAccount
BEFORE DELETE ON Customer
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1 FROM Account
        WHERE Customer_ID = OLD.Customer_ID
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Customer cannot be deleted while an account exists';
    END IF;
END //
DELIMITER ;

-- QUESTION 14
CREATE TABLE IF NOT EXISTS Account_Audit (
    Audit_ID INT PRIMARY KEY AUTO_INCREMENT,
    Account_No INT,
    Old_Balance DECIMAL(12,2),
    New_Balance DECIMAL(12,2),
    Changed_Date DATETIME DEFAULT CURRENT_TIMESTAMP
);

DELIMITER //
CREATE TRIGGER AccountBalanceAudit
AFTER UPDATE ON Account
FOR EACH ROW
BEGIN
    IF OLD.Balance <> NEW.Balance THEN
        INSERT INTO Account_Audit
        (Account_No, Old_Balance, New_Balance)
        VALUES
        (OLD.Account_No, OLD.Balance, NEW.Balance);
    END IF;
END //
DELIMITER ;

-- QUESTION 15
DELIMITER //
CREATE PROCEDURE Top5Accounts()
BEGIN
    SELECT *
    FROM Account
    ORDER BY Balance DESC
    LIMIT 5;
END //
DELIMITER ;

CALL Top5Accounts();

-- QUESTION 16
DELIMITER //
CREATE PROCEDURE AccountsByBranch()
BEGIN
    SELECT Branch, COUNT(*) AS Number_of_Accounts
    FROM Account
    GROUP BY Branch;
END //
DELIMITER ;

CALL AccountsByBranch();

-- QUESTION 17
DELIMITER //
CREATE PROCEDURE CustomersWithHighLoans(IN MinimumLoanAmount DECIMAL(12,2))
BEGIN
    SELECT C.Customer_ID, C.Customer_Name,
           L.Loan_ID, L.Loan_Type, L.Loan_Amount, L.Interest_Rate
    FROM Customer C
    JOIN Loan L ON C.Customer_ID = L.Customer_ID
    WHERE L.Loan_Amount > MinimumLoanAmount;
END //
DELIMITER ;

CALL CustomersWithHighLoans(1000000);

-- QUESTION 18
DELIMITER //
CREATE TRIGGER PreventAccountDeletionWithTransactions
BEFORE DELETE ON Account
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1 FROM Bank_Transaction
        WHERE Account_No = OLD.Account_No
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Account cannot be deleted because transactions exist';
    END IF;
END //
DELIMITER ;

-- QUESTION 19
DELIMITER //
CREATE PROCEDURE GetTransactionHistory(IN p_Account_No INT)
BEGIN
    SELECT *
    FROM Bank_Transaction
    WHERE Account_No = p_Account_No
    ORDER BY Transaction_Date;
END //
DELIMITER ;

CALL GetTransactionHistory(10001);

-- QUESTION 20
DELIMITER //
CREATE PROCEDURE GetAllAccountSummary()
BEGIN
    SELECT A.Account_No,
           C.Customer_Name,
           A.Account_Type,
           A.Balance,
           A.Branch
    FROM Account A
    JOIN Customer C ON A.Customer_ID = C.Customer_ID
    ORDER BY A.Account_No;
END //
DELIMITER ;

CALL GetAllAccountSummary();