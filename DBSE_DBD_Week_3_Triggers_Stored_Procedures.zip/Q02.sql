-- DBSE & DBD - Week 3 Practical
-- Bank Database - Triggers and Stored Procedures
-- Based on the uploaded practical material

CREATE DATABASE IF NOT EXISTS BankDB;
USE BankDB;

CREATE TABLE IF NOT EXISTS Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(15),
    Email VARCHAR(100),
    City VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Account (
    Account_No INT PRIMARY KEY,
    Customer_ID INT,
    Account_Type VARCHAR(20),
    Balance DECIMAL(12,2) DEFAULT 0,
    Branch VARCHAR(50),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

CREATE TABLE IF NOT EXISTS Bank_Transaction (
    Transaction_ID INT PRIMARY KEY AUTO_INCREMENT,
    Account_No INT,
    Transaction_Type VARCHAR(20),
    Amount DECIMAL(12,2),
    Transaction_Date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Account_No) REFERENCES Account(Account_No)
);

CREATE TABLE IF NOT EXISTS Loan (
    Loan_ID INT PRIMARY KEY,
    Customer_ID INT,
    Loan_Type VARCHAR(30),
    Loan_Amount DECIMAL(12,2),
    Interest_Rate DECIMAL(5,2),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

INSERT IGNORE INTO Customer VALUES
(101,'Ravi Kumar','9876543210','ravi@gmail.com','Hyderabad'),
(102,'Priya Sharma','9876543211','priya@gmail.com','Vijayawada'),
(103,'Arjun Reddy','9876543212','arjun@gmail.com','Bangalore'),
(104,'Sneha Rao','9876543213','sneha@gmail.com','Chennai'),
(105,'Kiran Kumar','9876543214','kiran@gmail.com','Hyderabad');

INSERT IGNORE INTO Account VALUES
(10001,101,'Savings',50000,'Hyderabad'),
(10002,102,'Savings',75000,'Vijayawada'),
(10003,103,'Current',120000,'Bangalore'),
(10004,104,'Savings',45000,'Chennai'),
(10005,105,'Current',90000,'Hyderabad');

INSERT IGNORE INTO Loan VALUES
(501,101,'Home Loan',5000000,7.5),
(502,102,'Education Loan',1000000,6.5),
(503,103,'Car Loan',800000,8.2),
(504,104,'Personal Loan',500000,10.5);


-- ANSWER TO QUESTION 2
DELIMITER //
CREATE PROCEDURE GetCustomerAccountDetails(IN p_Customer_ID INT)
BEGIN
    SELECT C.Customer_Name, C.Phone, C.Email,
           A.Account_No, A.Account_Type, A.Balance
    FROM Customer C
    JOIN Account A ON C.Customer_ID = A.Customer_ID
    WHERE C.Customer_ID = p_Customer_ID;
END //
DELIMITER ;

CALL GetCustomerAccountDetails(101);
