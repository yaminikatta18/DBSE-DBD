-- DBSE & DBD - Week 1 Constraint Tests
-- Run this AFTER Week_1_BookFlow.sql
-- Each query below is intentionally invalid and should fail.

USE bookflow_db;

-- Test 1: Duplicate ISBN
INSERT INTO books (title, isbn, published_year)
VALUES ('Fake Copy', '9780061122415', 2000);

-- Test 2: NULL title
INSERT INTO books (title, isbn, published_year)
VALUES (NULL, '9999999999999', 2010);

-- Test 3: Future publication year
INSERT INTO books (title, isbn, published_year)
VALUES ('Time Traveler', '8888888888888', 2030);

-- Test 4: Duplicate email
INSERT INTO members (full_name, email)
VALUES ('Anil Clone', 'anil.kumar@example.com');
