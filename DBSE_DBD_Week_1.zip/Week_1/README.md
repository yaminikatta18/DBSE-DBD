# DBSE & DBD - Week 1

## Practical
BookFlow Library Database

## Files
- `Week_1_BookFlow.sql` - database, tables, constraints, valid sample data, verification queries.
- `Week_1_Constraint_Tests.sql` - four intentionally failing constraint tests.

## MySQL Run Order
1. Open MySQL Workbench.
2. Open `Week_1_BookFlow.sql`.
3. Execute the script.
4. Open `Week_1_Constraint_Tests.sql`.
5. Run each invalid INSERT separately and capture the error messages.
6. Keep screenshots of `DESCRIBE` and `SELECT` outputs for the practical evidence.

## Concepts
- CREATE DATABASE
- CREATE TABLE
- PRIMARY KEY
- AUTO_INCREMENT
- NOT NULL
- UNIQUE
- CHECK
- INSERT
- SELECT
- DESCRIBE
