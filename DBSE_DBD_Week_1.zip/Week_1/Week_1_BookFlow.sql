-- DBSE & DBD - Week 1 Practical
-- Course Code: 25CS1302E
-- Scenario: BookFlow Library Database
-- MySQL

-- =========================================================
-- 1. DATABASE SETUP
-- =========================================================

CREATE DATABASE IF NOT EXISTS bookflow_db;
USE bookflow_db;

-- =========================================================
-- 2. TABLE CREATION WITH CONSTRAINTS
-- =========================================================

DROP TABLE IF EXISTS members;
DROP TABLE IF EXISTS books;

CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    isbn VARCHAR(13) NOT NULL UNIQUE,
    published_year INT,
    CONSTRAINT chk_published_year CHECK (published_year < 2027)
);

CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE
);

-- =========================================================
-- 3. VERIFY TABLE STRUCTURE
-- =========================================================

DESCRIBE books;
DESCRIBE members;

-- =========================================================
-- 4. INSERT VALID SAMPLE DATA
-- =========================================================

INSERT INTO books (title, isbn, published_year) VALUES
('The Alchemist', '9780061122415', 1988),
('Clean Code', '9780132350884', 2008),
('Atomic Habits', '9780735211292', 2018);

INSERT INTO members (full_name, email) VALUES
('Anil Kumar', 'anil.kumar@example.com'),
('Priya Sharma', 'priya.sharma@example.com'),
('Ravi Verma', 'ravi.verma@example.com');

-- =========================================================
-- 5. VERIFY INSERTED DATA
-- =========================================================

SELECT * FROM books;
SELECT * FROM members;

-- =========================================================
-- 6. CONSTRAINT TESTS
-- NOTE:
-- The following four INSERT statements are intentionally
-- invalid and MUST be rejected by MySQL.
-- Run them individually after the valid queries above.
-- =========================================================

-- TEST 1: Duplicate ISBN -> UNIQUE constraint violation
-- INSERT INTO books (title, isbn, published_year)
-- VALUES ('Fake Copy', '9780061122415', 2000);

-- TEST 2: NULL title -> NOT NULL constraint violation
-- INSERT INTO books (title, isbn, published_year)
-- VALUES (NULL, '9999999999999', 2010);

-- TEST 3: Future publication year -> CHECK constraint violation
-- INSERT INTO books (title, isbn, published_year)
-- VALUES ('Time Traveler', '8888888888888', 2030);

-- TEST 4: Duplicate email -> UNIQUE constraint violation
-- INSERT INTO members (full_name, email)
-- VALUES ('Anil Clone', 'anil.kumar@example.com');

-- =========================================================
-- END OF WEEK 1 PRACTICAL
-- =========================================================
