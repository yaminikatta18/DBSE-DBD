-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 12 - GROUP BY + ORDER BY
=========================================================

SCENARIO:
HR wants to see positions ranked by number
of employees.

QUERY:

SELECT position,
       COUNT(*) AS Total_Employees
FROM physician
GROUP BY position
ORDER BY Total_Employees DESC;

OUTPUT:

Surgical Attending Physician      3
All other positions               1

=========================================================
