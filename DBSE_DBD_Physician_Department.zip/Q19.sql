-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 19 - MAX()
=========================================================

SCENARIO:
Management wants the highest employee ID
currently assigned.

QUERY:

SELECT MAX(employeeid)
FROM physician;

OUTPUT:

9

=========================================================
