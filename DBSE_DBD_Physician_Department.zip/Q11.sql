-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 11 - SUBQUERY
=========================================================

SCENARIO:
Find physicians who are not department heads.

QUERY:

SELECT *
FROM physician
WHERE employeeid NOT IN
(
    SELECT head
    FROM department
);

OUTPUT:

John Dorian
Elliot Reid
Christopher Turk
Bob Kelso
Todd Quinlan
Keith Dudemeister

=========================================================
