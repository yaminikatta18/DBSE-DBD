-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 4 - COUNT()
=========================================================

SCENARIO:
The hospital wants to know the total number of
physicians currently employed.

QUERY:

SELECT COUNT(*) AS Total_Physicians
FROM physician;

OUTPUT:

9

=========================================================
