-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 9 - ORDER BY DESC
=========================================================

SCENARIO:
Management wants to see physician records
sorted by employee ID from highest to lowest.

QUERY:

SELECT *
FROM physician
ORDER BY employeeid DESC;

OUTPUT:

9 Molly Clock
8 Keith Dudemeister
7 John Wen
6 Todd Quinlan
5 Bob Kelso
4 Percival Cox
3 Christopher Turk
2 Elliot Reid
1 John Dorian

=========================================================
