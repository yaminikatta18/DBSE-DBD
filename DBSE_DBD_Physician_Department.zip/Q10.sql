-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 10 - WHERE + IN
=========================================================

SCENARIO:
The CEO wants details of department heads only.

QUERY:

SELECT *
FROM physician
WHERE employeeid IN
(
    SELECT head
    FROM department
);

OUTPUT:

Percival Cox
John Wen
Molly Clock

=========================================================
