-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 7 - GROUP BY + HAVING
=========================================================

SCENARIO:
The HR team wants to find positions occupied
by more than one physician.

QUERY:

SELECT position,
       COUNT(*) AS Total_Employees
FROM physician
GROUP BY position
HAVING COUNT(*) > 1;

OUTPUT:

Position                              Total_Employees
------------------------------------------------------
Surgical Attending Physician                 3

=========================================================
