-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 20 - MIN()
=========================================================

SCENARIO:
Management wants the earliest employee ID
currently assigned.

QUERY:

SELECT MIN(employeeid)
FROM physician;

OUTPUT:

1

=========================================================
TOPICS COVERED
=========================================================

1. WHERE
2. LIKE
3. NOT LIKE
4. IN
5. NOT IN
6. EXISTS
7. GROUP BY
8. HAVING
9. ORDER BY
10. INNER JOIN
11. SUBQUERY
12. COUNT()
13. COUNT(DISTINCT)
14. MIN()
15. MAX()

=========================================================
END OF PHYSICIAN & DEPARTMENT SQL NOTES
=========================================================
