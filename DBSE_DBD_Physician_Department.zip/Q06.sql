-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 6 - GROUP BY
=========================================================

SCENARIO:
The HR manager wants to know how many physicians
are working in each position.

QUERY:

SELECT position,
       COUNT(*) AS Total_Employees
FROM physician
GROUP BY position;

OUTPUT:

Position                              Total_Employees
------------------------------------------------------
Attending Physician                          1
Attending Psychiatrist                       1
Head Chief of Medicine                       1
MD Resident                                  1
Senior Attending Physician                   1
Staff Internist                              1
Surgical Attending Physician                 3

=========================================================
