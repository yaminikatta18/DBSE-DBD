-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 8 - ORDER BY
=========================================================

SCENARIO:
Hospital management wants an alphabetical
directory of physicians.

QUERY:

SELECT *
FROM physician
ORDER BY name ASC;

OUTPUT:

Bob Kelso
Christopher Turk
Elliot Reid
John Dorian
John Wen
Keith Dudemeister
Molly Clock
Percival Cox
Todd Quinlan

=========================================================
