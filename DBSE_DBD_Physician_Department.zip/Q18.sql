-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 18 - EXISTS
=========================================================

SCENARIO:
Find departments that currently have a valid head.

QUERY:

SELECT *
FROM department d
WHERE EXISTS
(
    SELECT 1
    FROM physician p
    WHERE p.employeeid=d.head
);

OUTPUT:

General Medicine
Surgery
Psychiatry

=========================================================
