-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 3 - WHERE + LIKE
=========================================================

SCENARIO:
Management wants to identify physicians whose names
start with 'John'.

QUERY:

SELECT *
FROM physician
WHERE name LIKE 'John%';

OUTPUT:

John Dorian
John Wen

=========================================================
