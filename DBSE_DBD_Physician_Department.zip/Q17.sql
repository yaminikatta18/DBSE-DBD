-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 17 - COUNT + HAVING
=========================================================

SCENARIO:
Find positions having at least 2 employees.

QUERY:

SELECT position,
       COUNT(*) AS Total
FROM physician
GROUP BY position
HAVING COUNT(*) >= 2;

OUTPUT:

Surgical Attending Physician     3

=========================================================
