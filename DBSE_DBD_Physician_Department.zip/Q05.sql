-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 5 - COUNT DISTINCT
=========================================================

SCENARIO:
HR wants to know how many different job positions
exist in the hospital.

QUERY:

SELECT COUNT(DISTINCT position)
FROM physician;

OUTPUT:

6

=========================================================
