-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 15 - JOIN + ORDER BY
=========================================================

SCENARIO:
Hospital administration wants department names
and head physicians sorted by department name.

QUERY:

SELECT d.name,
       p.name
FROM department d
JOIN physician p
ON d.head=p.employeeid
ORDER BY d.name;

OUTPUT:

General Medicine    Percival Cox
Psychiatry          Molly Clock
Surgery             John Wen

=========================================================
