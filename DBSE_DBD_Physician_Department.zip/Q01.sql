-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 1 - INNER JOIN
=========================================================

SCENARIO:
The hospital administration wants a report showing
each department and its department head.

QUERY:

SELECT d.name AS Department,
       p.name AS Head_Physician
FROM department d
JOIN physician p
ON d.head = p.employeeid;

OUTPUT:

Department          Head_Physician
----------------------------------
General Medicine    Percival Cox
Surgery             John Wen
Psychiatry          Molly Clock

=========================================================
