-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 14 - JOIN + WHERE
=========================================================

SCENARIO:
The hospital wants to know who heads the
Surgery department.

QUERY:

SELECT p.name
FROM physician p
JOIN department d
ON p.employeeid=d.head
WHERE d.name='Surgery';

OUTPUT:

John Wen

=========================================================
