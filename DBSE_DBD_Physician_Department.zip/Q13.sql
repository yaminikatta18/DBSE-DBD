-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 13 - WHERE + LIKE
=========================================================

SCENARIO:
The administration wants all physicians whose
position contains the word 'Attending'.

QUERY:

SELECT *
FROM physician
WHERE position LIKE '%Attending%';

OUTPUT:

Elliot Reid
Christopher Turk
Percival Cox
Todd Quinlan
John Wen
Molly Clock

=========================================================
