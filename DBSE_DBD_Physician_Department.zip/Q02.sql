-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 2 - WHERE CLAUSE
=========================================================

SCENARIO:
The HR department wants a list of all physicians
working as Surgical Attending Physicians.

QUERY:

SELECT *
FROM physician
WHERE position='Surgical Attending Physician';

OUTPUT:

Christopher Turk
Todd Quinlan
John Wen

=========================================================
