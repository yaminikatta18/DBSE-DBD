-- DBSE & DBD - Physician & Department SQL Practice

QUESTION 16 - WHERE + NOT LIKE
=========================================================

SCENARIO:
Find physicians who are not involved in surgery.

QUERY:

SELECT *
FROM physician
WHERE position NOT LIKE '%Surgical%';

OUTPUT:

John Dorian
Elliot Reid
Percival Cox
Bob Kelso
Keith Dudemeister
Molly Clock

=========================================================
