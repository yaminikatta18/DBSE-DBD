-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 2 - INNER JOIN
=========================================================

SCENARIO:
Management wants only students whose address details
are available in both tables.

QUERY:

SELECT *
FROM class
INNER JOIN class_info
ON class.id = class_info.id;

OUTPUT:

id  name   id  address
-----------------------
1   abhi   1   DELHI
2   adam   2   MUMBAI
3   alex   3   CHENNAI

=========================================================
