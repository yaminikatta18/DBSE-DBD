-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 14 - UNION ALL
=========================================================

SCENARIO:
Count total records from both branches.

QUERY:

SELECT COUNT(*)
FROM
(
SELECT * FROM first_table
UNION ALL
SELECT * FROM second_table
) A;

OUTPUT:

4

=========================================================
PART 9: INTERSECT
=========================================================
