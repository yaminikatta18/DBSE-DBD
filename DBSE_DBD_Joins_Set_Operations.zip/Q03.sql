-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 3 - INNER JOIN
=========================================================

SCENARIO:
Find student names and addresses for registered students.

QUERY:

SELECT class.name,
       class_info.address
FROM class
INNER JOIN class_info
ON class.id=class_info.id;

OUTPUT:

abhi   DELHI
adam   MUMBAI
alex   CHENNAI

=========================================================
PART 3: NATURAL JOIN
=========================================================
