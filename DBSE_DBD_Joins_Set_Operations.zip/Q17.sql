-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 17 - MINUS
=========================================================

SCENARIO:
Find students present only in the first branch.

QUERY:

SELECT * FROM first_table
MINUS
SELECT * FROM second_table;

OUTPUT:

1 abhi

=========================================================
