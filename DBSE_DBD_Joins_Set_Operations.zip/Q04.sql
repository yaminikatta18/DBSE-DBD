-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 4 - NATURAL JOIN
=========================================================

SCENARIO:
The database administrator wants matching records
automatically joined using common columns.

QUERY:

SELECT *
FROM class
NATURAL JOIN class_info;

OUTPUT:

id  name   address
------------------
1   abhi   DELHI
2   adam   MUMBAI
3   alex   CHENNAI

=========================================================
PART 4: LEFT OUTER JOIN
=========================================================

INSERT INTO class VALUES
(5,'ashish');

INSERT INTO class_info VALUES
(7,'NOIDA'),
(8,'PANIPAT');

=========================================================
