-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 6 - LEFT JOIN
=========================================================

SCENARIO:
Find students who do not have address records.

QUERY:

SELECT *
FROM class
LEFT JOIN class_info
ON class.id=class_info.id
WHERE class_info.id IS NULL;

OUTPUT:

4  anu
5  ashish

=========================================================
PART 5: RIGHT OUTER JOIN
=========================================================
