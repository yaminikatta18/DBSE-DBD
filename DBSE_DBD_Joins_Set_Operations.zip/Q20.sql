-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 20

SCENARIO:
Generate a report showing all students and address
availability status.

QUERY:

SELECT c.id,
       c.name,
       CASE
           WHEN ci.address IS NULL
           THEN 'Address Missing'
           ELSE 'Address Available'
       END AS Status
FROM class c
LEFT JOIN class_info ci
ON c.id=ci.id;

OUTPUT:

1 abhi    Address Available
2 adam    Address Available
3 alex    Address Available
4 anu     Address Missing
5 ashish  Address Missing

=========================================================
TOPICS COVERED
=========================================================

1. CROSS JOIN
2. INNER JOIN
3. NATURAL JOIN
4. LEFT OUTER JOIN
5. RIGHT OUTER JOIN
6. FULL OUTER JOIN
7. UNION
8. UNION ALL
9. INTERSECT
10. MINUS
11. CASE
12. JOIN + WHERE
13. JOIN + NULL
14. JOIN + FILTERING

=========================================================
END OF SQL JOIN & SET OPERATION NOTES
=========================================================
