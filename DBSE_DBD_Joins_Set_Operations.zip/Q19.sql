-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 19

SCENARIO:
Find students having matching addresses.

QUERY:

SELECT c.id,c.name,ci.address
FROM class c
INNER JOIN class_info ci
ON c.id=ci.id;

=========================================================
