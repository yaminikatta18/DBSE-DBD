-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 1 - CROSS JOIN
=========================================================

SCENARIO:
School administration wants every student to be paired
with every available city for survey analysis.

QUERY:

SELECT *
FROM class
CROSS JOIN class_info;

OUTPUT:

id  name   id  address
-----------------------
1   abhi   1   DELHI
2   adam   1   DELHI
4   alex   1   DELHI
1   abhi   2   MUMBAI
2   adam   2   MUMBAI
4   alex   2   MUMBAI
1   abhi   3   CHENNAI
2   adam   3   CHENNAI
4   alex   3   CHENNAI

=========================================================
PART 2: INNER JOIN
=========================================================

CREATE TABLE class (
    id INT,
    name VARCHAR(30)
);

CREATE TABLE class_info (
    id INT,
    address VARCHAR(30)
);

INSERT INTO class VALUES
(1,'abhi'),
(2,'adam'),
(3,'alex'),
(4,'anu');

INSERT INTO class_info VALUES
(1,'DELHI'),
(2,'MUMBAI'),
(3,'CHENNAI');

=========================================================
