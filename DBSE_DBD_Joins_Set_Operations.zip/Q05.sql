-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 5 - LEFT JOIN
=========================================================

SCENARIO:
School wants all students even if address information
is not available.

QUERY:

SELECT *
FROM class
LEFT OUTER JOIN class_info
ON class.id=class_info.id;

OUTPUT:

1  abhi    1  DELHI
2  adam    2  MUMBAI
3  alex    3  CHENNAI
4  anu     NULL NULL
5  ashish  NULL NULL

=========================================================
