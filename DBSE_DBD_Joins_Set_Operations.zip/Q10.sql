-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 10 - FULL OUTER JOIN
=========================================================

SCENARIO:
Audit team wants unmatched records from both tables.

QUERY:

SELECT *
FROM class
FULL OUTER JOIN class_info
ON class.id=class_info.id
WHERE class.id IS NULL
OR class_info.id IS NULL;

OUTPUT:

4 anu
5 ashish
7 NOIDA
8 PANIPAT

=========================================================
PART 7: UNION
=========================================================

CREATE TABLE first_table(
id INT,
name VARCHAR(30)
);

CREATE TABLE second_table(
id INT,
name VARCHAR(30)
);

INSERT INTO first_table VALUES
(1,'abhi'),
(2,'adam');

INSERT INTO second_table VALUES
(2,'adam'),
(3,'chester');

=========================================================
