-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 8 - RIGHT JOIN
=========================================================

SCENARIO:
Find address records that do not belong to any student.

QUERY:

SELECT *
FROM class
RIGHT JOIN class_info
ON class.id=class_info.id
WHERE class.id IS NULL;

OUTPUT:

7  NOIDA
8  PANIPAT

=========================================================
PART 6: FULL OUTER JOIN
=========================================================
