-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 16 - INTERSECT
=========================================================

SCENARIO:
Find common student names.

QUERY:

SELECT name FROM first_table
INTERSECT
SELECT name FROM second_table;

OUTPUT:

adam

=========================================================
PART 10: MINUS
=========================================================
