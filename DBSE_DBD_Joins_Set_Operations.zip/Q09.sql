-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 9 - FULL OUTER JOIN
=========================================================

SCENARIO:
Management wants all records from both tables,
matched and unmatched.

QUERY:

SELECT *
FROM class
FULL OUTER JOIN class_info
ON class.id=class_info.id;

OUTPUT:

1 abhi    1 DELHI
2 adam    2 MUMBAI
3 alex    3 CHENNAI
4 anu     NULL NULL
5 ashish  NULL NULL
NULL NULL 7 NOIDA
NULL NULL 8 PANIPAT

=========================================================
