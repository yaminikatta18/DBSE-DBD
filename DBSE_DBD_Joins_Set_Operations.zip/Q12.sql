-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 12 - UNION
=========================================================

SCENARIO:
Generate a master student list from two branches.

QUERY:

SELECT name FROM first_table
UNION
SELECT name FROM second_table;

OUTPUT:

abhi
adam
chester

=========================================================
PART 8: UNION ALL
=========================================================
