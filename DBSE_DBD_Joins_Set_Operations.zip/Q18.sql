-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 18 - MINUS
=========================================================

SCENARIO:
Find names that exist only in first_table.

QUERY:

SELECT name FROM first_table
MINUS
SELECT name FROM second_table;

OUTPUT:

abhi

=========================================================
ADVANCED INTERVIEW QUESTIONS
=========================================================
