-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 15 - INTERSECT
=========================================================

SCENARIO:
Find students present in both branches.

QUERY:

SELECT * FROM first_table
INTERSECT
SELECT * FROM second_table;

OUTPUT:

2 adam

=========================================================
