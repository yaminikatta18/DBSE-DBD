-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 11 - UNION
=========================================================

SCENARIO:
Management wants a combined list without duplicates.

QUERY:

SELECT * FROM first_table
UNION
SELECT * FROM second_table;

OUTPUT:

1 abhi
2 adam
3 chester

=========================================================
