-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 13 - UNION ALL
=========================================================

SCENARIO:
Management wants all records including duplicates.

QUERY:

SELECT * FROM first_table
UNION ALL
SELECT * FROM second_table;

OUTPUT:

1 abhi
2 adam
2 adam
3 chester

=========================================================
