-- DBSE & DBD
-- TOPIC: JOINS AND SET OPERATIONS
-- Source: Provided Week material

QUESTION 7 - RIGHT JOIN
=========================================================

SCENARIO:
Administration wants all address records even if
students are missing.

QUERY:

SELECT *
FROM class
RIGHT OUTER JOIN class_info
ON class.id=class_info.id;

OUTPUT:

1  abhi  1  DELHI
2  adam  2  MUMBAI
3  alex  3  CHENNAI
NULL NULL 7 NOIDA
NULL NULL 8 PANIPAT

=========================================================
